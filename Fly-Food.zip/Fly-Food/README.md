# Fly-Food

A Yummy Android Game! <br />

### Features
- Player high-score persistes.
- Sophisticated animations (Rotation, scaling, and translation)
- Cool sound tracks
- Simple and refreshing UI

### Screenshots

<table>
  <tr>
    <td> <img src="screenshots/01.png"  title="1"></td>
    <td> <img src="screenshots/02.png"  title="2"></td>
    <td> <img src="screenshots/03.png"  title="3"></td>
    <td> <img src="screenshots/04.png"  title="4"></td>
  </tr>
</table>
